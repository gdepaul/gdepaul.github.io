/***********************************************************************
 * Gregory DePaul
 * UndoLastCommand.java
 *
 * Project 2 - Collab Editing
 * Allow clients to undo the last command from the server. 
 ***********************************************************************/

public class UndoLastCommand<T> extends Command<T> {

	private static final long serialVersionUID = 1L;
	
	String clientID;

	public UndoLastCommand(String source) {
		clientID = source;
	}
	
	public void execute(T aType) {
		if(aType instanceof IDEServer)
			run((IDEServer) aType);
	}

	public void run(IDEServer aType) {
		aType.undoLast(clientID);
	}

}
