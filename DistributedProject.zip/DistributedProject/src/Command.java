/***********************************************************************
 * Gregory DePaul
 * Command.java
 *
 * Project 2 - Collab Editing
 * Serves as the command design pattern. 
 ***********************************************************************/

import java.io.Serializable;

public abstract class Command<T> implements Serializable {

	public abstract void execute(T aType);

}
