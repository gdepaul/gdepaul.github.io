/***********************************************************************
 * Gregory DePaul
 * IDEClient.java
 *
 * Project 2 - Collab Editing
 * Client Side Application
 ***********************************************************************/

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import javax.swing.AbstractAction;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.KeyStroke;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.UndoableEditEvent;
import javax.swing.event.UndoableEditListener;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.undo.UndoManager;

public class IDEClient extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private Socket server; // connection to server
	private ObjectOutputStream output; // output stream
	private ObjectInputStream input; // input stream
	private boolean write = true;
	private String userID;
	
	private JTextPane myTextArea;
	
	private String myText;
	
	private MyDocumentListener myDocumentListener = new MyDocumentListener();
	
	/***********************************************
	 * Attempt to connect to the server
	 ***********************************************/ 
	public IDEClient() {
		
		try {
			// ask the user for a host, port, and user name
			String host = JOptionPane.showInputDialog("Host address:");
			int port = 8989;
			userID = JOptionPane.showInputDialog("User name:");
			
			server = new Socket(host, port);
			output = new ObjectOutputStream(server.getOutputStream());
			input = new ObjectInputStream(server.getInputStream());
			
			for(String check = "reject"; check.equals("reject");) {
				// write out the name of this client
				output.writeObject(userID);
				// Check to see if the client is accepted
				check = (String)input.readObject();
				if(check.equals("reject"))
					userID = JOptionPane.showInputDialog("Name Already Taken: User name:");
			}
						
			// add a listener that sends a disconnect command to the server when closing
			this.addWindowListener(new WindowAdapter(){
				public void windowClosing(WindowEvent arg0) {
					try {
						output.writeObject(new DisconnectCommand(userID));
						output.close();
						input.close();
					} catch (IOException e) {}
				}
			});
			
			new Thread(new ServerHandler()).start();
		}
		catch(Exception E) {}
		
		setupGUI();
		setupSync();
	}
	
	/***********************************************
	 * Sync text with that on the server
	 ***********************************************/ 
	public void setupSync(){
	    myTextArea.getDocument().addDocumentListener(myDocumentListener);
	}
	
	/***********************************************
	 * Update text with that on the server
	 ***********************************************/ 
	public void update(String newText){
		write = false;
		myText = newText;
		myTextArea.setText(myText);
		// I need to correctly reset the carat
		myTextArea.setCaretPosition(myTextArea.getDocument().getLength());
	}

	/***********************************************
	 * Create the gui in the client once signed in
	 ***********************************************/ 
	private void setupGUI() {
		this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// add a JTextPanel
		myTextArea = new JTextPane();
		myTextArea.setBounds(30, 30, 720, 520);
		myTextArea.setVisible(true);
		this.add(myTextArea);
		
		this.setVisible(true);
		
		/***********************************************
		 * Undo listener 
		 ***********************************************/
		final UndoManager undo = new UndoManager();
	    Document doc = myTextArea.getDocument();

	    doc.addUndoableEditListener(new UndoableEditListener() {

	    	public void undoableEditHappened(UndoableEditEvent evt) {
	    		undo.addEdit(evt.getEdit());
			}
	    });

	    myTextArea.getActionMap().put("Undo", new AbstractAction("Undo") {
	      public void actionPerformed(ActionEvent evt) {
	    	  System.out.println("Attempting to undo");
	        	  try {
					output.writeObject(new UndoLastCommand(userID));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	      }
	    });
	    
	    myTextArea.getInputMap().put(KeyStroke.getKeyStroke("control Z"), "Undo");
	}

	/***********************************************
	 * Main method in order to run the client
	 ***********************************************/ 
	public static void main(String[] args){
		new IDEClient();
	}
	
	
	/***********************************************
	 * Provides a thread to continually accepts
	 * commands from the server. This will then
	 * execute the command object. 
	 ***********************************************/
	private class ServerHandler implements Runnable {
		
		public void run() {
			//Implement the ServerHandler
			while(true) {
				try {
					Object obj = input.readObject();
					if(obj instanceof Command<?>) { // See if we have a valid command
						Command<IDEClient> command = (Command<IDEClient>)obj;
						command.execute(IDEClient.this);
					}	
				} catch (Exception e) {} //this will block if no object written
			}
		}
	}
	
	/***********************************************
	 * Listen for all changes made to the document. 
	 ***********************************************/
	private class MyDocumentListener implements DocumentListener {
	    public void insertUpdate(DocumentEvent e) {
	        updateLog(e, "inserted into");
	    }
	    public void removeUpdate(DocumentEvent e) {
	        updateLog(e, "removed from");
	    }
	    public void changedUpdate(DocumentEvent e) {
	        //Plain text components do not fire these events
	    }

	    public void updateLog(final DocumentEvent e, final String action) {
	    	if(write || myText.equals("")) {
	    		try {
	    			myText = myTextArea.getDocument().getText(0, myTextArea.getDocument().getLength());
	    		} catch (BadLocationException e1) {
	    			// TODO Auto-generated catch block
	    			e1.printStackTrace();
	    		}
	        	try {
	        		output.writeObject(new UpdateCommand<IDEServer>(myText));
	        	} catch (IOException e1) {
	        		// TODO Auto-generated catch block
	        		e1.printStackTrace();
	        	}
	    	}
	    	else {
	    		write = true;
	    	}
	    }
	}
	
}