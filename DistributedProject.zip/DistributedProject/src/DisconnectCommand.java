/***********************************************************************
 * Gregory DePaul
 * DisconnectCommand.java
 *
 * Project 2 - Collab Editing
 * Allow clients to disconnect from the server. 
 ***********************************************************************/

public class DisconnectCommand<T> extends Command<T> {

	private static final long serialVersionUID = 1L;
	
	String disconnectID;

	public DisconnectCommand(String source) {
		disconnectID = source;
	}

	@Override
	public void execute(T aType) {
		if(aType instanceof IDEServer)
			run((IDEServer) aType);
	}
	
	public void run(IDEServer aType) {
		aType.disconnect(disconnectID); // Free up that user's name
	}

}
