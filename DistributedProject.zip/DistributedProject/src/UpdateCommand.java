/***********************************************************************
 * Gregory DePaul
 * UpdateCommand.java
 *
 * Project 2 - Collab Editing
 * Allow clients to add text to the current document.
 ***********************************************************************/

public class UpdateCommand<T> extends Command<T> {

	private static final long serialVersionUID = 1L;
	String myString;
	
	public UpdateCommand(String newString) {
		myString = new String(newString);
	}
	
	public void execute(T aType) {
		if(aType instanceof IDEServer)
			run((IDEServer) aType);
		else if(aType instanceof IDEClient)
			run((IDEClient) aType);
	}

	private void run(IDEClient myClient) {
		myClient.update(myString);
	}

	public void run(IDEServer myServer) {
		if(myServer.currentText().equals(myString));
		else {
			myServer.addObject(myString);
		}
	}

}
