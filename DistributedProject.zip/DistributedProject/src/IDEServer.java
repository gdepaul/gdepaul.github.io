/***********************************************************************
 * Gregory DePaul
 * IDEServer.java
 *
 * Project 2 - Collab Editing
 * Server to handle collaboration.
 ***********************************************************************/

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Collections;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;

public class IDEServer {
	private ServerSocket socket;
	private List<String> revisions;
	
	private Map<String, Deque<Command<IDEServer>>> histories;
	private Map<String, ObjectInputStream> inputs;
	private Map<String, ObjectOutputStream> outputs;
	
	/***********************************************
	 * Handle all client commands
	 ***********************************************/ 
	private class ClientHandler implements Runnable{
		
		private String clientId; // name of the client
		private Deque<Command<IDEServer>> history; // history of executed commands
		private ObjectInputStream input; // input stream to read command from
		
		public ClientHandler(String id, Deque<Command<IDEServer>> history)
		{
			clientId = id;
			this.history=history;
			input = inputs.get(id);
			
			System.out.println("New Client " + id + " connected");
			
			updateClients();
		}

		public void run() {
			while(true){
				try{
					Object ob = input.readObject();
					if (ob instanceof Command<?>){
						Command<IDEServer> command = (Command<IDEServer>)ob; // cast the object // grab a command off the queue
						command.execute(IDEServer.this); // execute the command on the server
					
					if (!(command instanceof UndoLastCommand)) // undo commands can't be undone
							history.push(command);
					}
				}
				catch(Exception e){
					//System.err.println("In Client Handler:");
					//e.printStackTrace();
					break;
				}
			}
		}
	}
	
	/***********************************************
	 * Constantly be able to accept new clients.
	 ***********************************************/
	private class ClientAccepter implements Runnable{
		public void run() {
			while (true){
				try{
					Socket s = socket.accept(); // wait for a new client
					
					// grab the output and input streams for the new client
					ObjectOutputStream output = new ObjectOutputStream(s.getOutputStream());
					ObjectInputStream input = new ObjectInputStream(s.getInputStream());
					

					String name;
					do{
						// read the client's name
						name = (String)input.readObject();
						
						// if that name is already connected, reject
						if (outputs.containsKey(name))
							output.writeObject("reject");
					}while (outputs.containsKey(name));
					
					// tell the client their name is accepted
					output.writeObject("accept");
					
					// add the output, input streams to the correct maps
					outputs.put(name, output);
					inputs.put(name, input);
					
					// create a command history queue for the new client
					histories.put(name, new LinkedBlockingDeque<Command<IDEServer>>());
					
					// start a new ClientHandler for this new client
					new Thread(new ClientHandler(name, histories.get(name))).start();
				}
				catch(Exception e){
					System.err.println("In Client Accepter:");
					e.printStackTrace();
					break;
				}
			}
		}
	}
	
	/***********************************************
	 * Create the server with the ability to hold
	 * revisions. 
	 ***********************************************/
	public IDEServer(int port){
		try{
			socket = new ServerSocket(port); // create a new server
			
			// setup hashmaps
			histories = new ConcurrentHashMap<String, Deque<Command<IDEServer>>>();
			inputs = new ConcurrentHashMap<String, ObjectInputStream>();
			outputs = new ConcurrentHashMap<String, ObjectOutputStream>();
			
			// create the list of Revisons
			revisions = Collections.synchronizedList(new LinkedList<String>());
			
			System.out.println("Server started on port " + port);
			
			// begin accepting clients
			new Thread(new ClientAccepter()).start();
		}catch(Exception e){
			System.err.println("Error creating server:");
			e.printStackTrace();
		}
	}
	
	/***********************************************
	 * Provide an undo statement 
	 ***********************************************/
	public void undoLast(String clientName) {
		if(revisions.size() > 0)
			revisions.remove(revisions.size()-1);
		updateClients();
	}

	/***********************************************
	 * Provide an update method to update all clients 
	 ***********************************************/
	public void updateClients(){
		Command<IDEClient> update = new UpdateCommand<IDEClient>(currentText());
		for (ObjectOutputStream out: outputs.values())
			try{
				out.writeObject(update);
			}catch(Exception e){
				System.err.println("Error updating clients");
//				//e.printStackTrace();
				outputs.remove(out);
				// Try to remove the client
			}
	}
	
	/***********************************************
	 * Update the current document
	 ***********************************************/ 
	public void addObject(String newString) {
		revisions.add(newString);
		updateClients();
	}
	
	/***********************************************
	 * What is the latest document?
	 ***********************************************/ 
	public String currentText() {
		if(revisions.size() > 0)
			return revisions.get(revisions.size()-1);
		else
			return "";
	}

	/***********************************************
	 * Allow for a user to disconnect from the server
	 ***********************************************/ 
	public void disconnect(String source) {
		System.out.printf("Client \'%s\' disconnecting\n", source);
		try{
			inputs.remove(source).close();
			outputs.remove(source).close();
			histories.remove(source);
		} catch(Exception e){e.printStackTrace();}
	}
	
	/***********************************************
	 * Establish a server with a specific port
	 ***********************************************/ 
	public static void main(String[] args)
	{
		new IDEServer(8989);
	}
}
