Author: Greg DePaul

This is an implementation of a Huffman Encoder in c. 
Included is a MakeFile. The create an executable, type: 

make Huffman

into your terminal window. To run the program, type

./Huffman <filename>

where the filename is the name of the text you would like to compress. 
The outputs of this program is:

codetable.txt
compressed.bin
