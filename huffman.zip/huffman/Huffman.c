/***********************************************************************
 * Gregory DePaul
 * Huffman.c
 *
 * Project 1 - Huffman Coding
 ***********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "BinaryTree.h"

/** Function Prototypes ************************************************/

void readInputFile(char* fileName, int charTotals[]);
void assignCodings(BinaryNode* head, char currentEncoding[], char* huffmanCodes[]);
void printOutFile(int charTotals[], char* huffmanCodes[], int totalCharacters);
float averageBitLength(int charTotals[], char* huffmanCodes[], int totalCharacters);
float calculateEntropy(int charTotals[], int totalCharacters);
void createCompressedFile(char* fileName, char* huffmanCodes[]);

/** Main ***************************************************************/

int main(int argc, char *argv[] ) {
    
    int charTotals[128];
    int i; // Iteration control
    char* huffmanCodes[128];
    int totalCharacters = 0;
    
    // No files to be processed
    if(argc == 1) {
        fprintf(stderr, "huffman fileName\n");
        return 1;
    }
    
    // Initialize the char totals to zero
    for(i = 0; i < 128; i++) {
        charTotals[i] = 0;
    }
    
    // Perform the initial read through of the file
    readInputFile(argv[1], charTotals);
    
    // Create list of nodes for all the characters
    LinkedRoot* myList = NULL;
    for(i = 0; i < 128; i++) {
        if(charTotals[i] != 0) {
            BinaryNode* newNode = newBinaryNode(i, charTotals[i]);
            LinkedRoot* newRoot = newLinkedRoot(newNode);
            myList = addRoot(myList, newRoot);
            totalCharacters += charTotals[i];
        }
    }
    
    // Perform the Huffman Coding Algoritm
    while(myList->next != NULL) {
        LinkedRoot* newJointRoot = newLinkedRoot(newBinaryNode(-1, -1));
        newJointRoot->data->left = myList->data;
        myList = removeLeastRoot(myList);
        newJointRoot->data->right = myList->data;
        myList = removeLeastRoot(myList);
        newJointRoot->data->frequency = newJointRoot->data->left->frequency + newJointRoot->data->right->frequency;
        myList = addRoot(myList, newJointRoot);
    }
    
    // Assign the codings by traversing the binary tree:
    assignCodings(myList->data, "", huffmanCodes);
    
    // Free the memory of myList and it's internal data
    freeList(myList);
    
    // Print the codings:
    printOutFile(charTotals, huffmanCodes, totalCharacters);
    
    // Generate Compressed File
    createCompressedFile(argv[1], huffmanCodes);
    
    return 0; // Return as successful completion
}

/** readInputFile ******************************************************/

void readInputFile(char* fileName, int charTotals[]) {
    
    FILE *inputFile; // Pointer to inputFile
    char ch;
    inputFile = fopen(fileName, "r"); // Open the input file
    
    if(inputFile != NULL) { // If the inputFile is valid
        
        // Read the file and initialize the charTotals array
        while(! feof(inputFile)) {
            ch = getc(inputFile);
            if( ch >= 0 && ch < 127)
                charTotals[(int)ch]++;
        }
        
        if(fclose(inputFile) != 0) { // If we failed to close the input file
            fprintf(stderr, "An error occurred when closing the file\n");
            exit(1);
        }
    }
    
    else {
        // If we failed to open the input file
        fprintf(stderr, "Unable to open %s for reading\n", fileName);
        exit(1);
    }
}

/** assignCodings ******************************************************/

void assignCodings(BinaryNode* head, char currentEncoding[], char* huffmanCodes[]) {

    char* nextEncoding;
    char* thisEncoding;

    if(head != NULL) {
        
        // Create a string for this specific end node
        thisEncoding = (char *)malloc((strlen(currentEncoding)+2)*sizeof(char));
        strcpy(thisEncoding, currentEncoding);
        
        if(head->value >= 0) {
            
            // Correct an issue with the encoding
            if(thisEncoding[0] == '0')
                thisEncoding[0] = '1';
            else
                thisEncoding[0] = '0';
            
            // Once we find a leaf node, establish the encoding
            huffmanCodes[head->value] = thisEncoding;
        }
        
        // Create the recursive string
        nextEncoding = (char *)malloc((strlen(currentEncoding)+2)*sizeof(char));
        strcpy(nextEncoding, thisEncoding);
        
        // Perform the recursive call on the left and right children
        nextEncoding[strlen(currentEncoding)] = '0';
        nextEncoding[strlen(currentEncoding) + 1] = 0;
        assignCodings(head->left, nextEncoding, huffmanCodes);
        nextEncoding[strlen(currentEncoding)] = '1';
        assignCodings(head->right, nextEncoding, huffmanCodes);
    }
    
}

/** averageBitLength ***************************************************/

float averageBitLength(int charTotals[], char* huffmanCodes[], int totalCharacters) {
    int totalBitsNeeded = 0, i;
    
    for(i = 0; i < 128; i++) {
        if(charTotals[i] != 0) {
            totalBitsNeeded += charTotals[i]*strlen(huffmanCodes[i]);
        }
    }
    
    return (float)totalBitsNeeded/totalCharacters;
}

/** calculateEntropy ***************************************************/

float calculateEntropy(int charTotals[], int totalCharacters) {
    
    int i;
    float myEntropy = 0.0;
    
    for(i = 0; i < 128; i++) {
        if(charTotals[i] != 0) {
            myEntropy += -1*((float)charTotals[i]/totalCharacters)* log2(((float)charTotals[i]/totalCharacters));
        }
    }
    
    return myEntropy;
}

/** printOutFile *******************************************************/

void printOutFile(int charTotals[], char* huffmanCodes[], int totalCharacters) {
    
    int i;
    
    FILE *codeTable; // Pointer to inputFile
    codeTable = fopen("codetable.txt", "w"); // Open the input file
    
    fprintf(codeTable, "Char 	 Frequency   	 Encoding\n");
    fprintf(codeTable, "---- 	 ---------      --------\n");
    for(i = 0; i < 128; i++) {
        if(charTotals[i] != 0) {
            if(i != 10 && i >= 32)
                fprintf(codeTable, "%2c: \t %-10.6f \t %-s\n", i, (float)100*charTotals[i]/totalCharacters, huffmanCodes[i]);
            else if(i < 32 && i != 10) {
                fprintf(codeTable, "~%d: \t %-10.6f \t %-s\n", i, (float)100*charTotals[i]/totalCharacters, huffmanCodes[i]);
            }
            else
                fprintf(codeTable, "NL: \t %-10.6f \t %-s\n", (float)100*charTotals[i]/totalCharacters, huffmanCodes[i]);
        }
    }
    
    fprintf(codeTable, "\nAverage Bits Per Symbol: %f\n", averageBitLength(charTotals, huffmanCodes, totalCharacters));
    fprintf(codeTable, "Entropy of the text: %f\n", calculateEntropy(charTotals, totalCharacters));
    
    if(fclose(codeTable) != 0) { // If we failed to close the code table file
        fprintf(stderr, "An error occurred when closing the code table file\n");
        exit(1);
    }
    
}

/** createCompressedFile ***********************************************/

void createCompressedFile(char* fileName, char* huffmanCodes[]) {
    
    FILE *inputFile; // Pointer to inputFile
    char ch;
    int buffer = 0;
    int length = 0;
    char* str;
    FILE* compressedFile;
    inputFile = fopen(fileName, "r"); // Open the input file
    
    compressedFile = fopen("compressed.bin","wb");
    
    if(inputFile != NULL) { // If the inputFile is valid
            
        // Read the file and convert each character to its binary equivalent
        while(! feof(inputFile)) {
            ch = getc(inputFile);
            if( ch >= 0 && ch < 127) {
                //printf("%s\n", huffmanCodes[ch]);
                for(str = huffmanCodes[(int)ch]; *str; str++) {
                    buffer *= 2;
                    if(*str == '0') {
                        buffer = buffer + 0;
                    }
                    else {
                        buffer = buffer + 1;
                    }
                    length++;
                    if(length == 8) {
                        //printf("%x\n", buffer);
                        fwrite(&buffer, 1, 1, compressedFile);
                        buffer = 0;
                        length = 0;
                    }
                }
            }
        }
        
        while(length < 8) {
            //printf("%x\n", buffer);
            buffer *= 2;
            length++;
        }
        
        fwrite(&buffer , 1 , 1, compressedFile);
        
        if(fclose(compressedFile) != 0) { // If we failed to close the compressed file
            fprintf(stderr, "An error occurred when closing the compressed file\n");
            exit(1);
        }
        
        if(fclose(inputFile) != 0) { // If we failed to close the input file
            fprintf(stderr, "An error occurred when closing the input file\n");
            exit(1);
        }
    }
    
    else {
        // If we failed to open the input file
        fprintf(stderr, "Unable to open %s for reading\n", fileName);
        exit(1);
    }
}

/***********************************************************************/