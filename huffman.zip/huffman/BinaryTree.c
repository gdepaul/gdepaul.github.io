/***********************************************************************
 * Gregory DePaul
 * BinaryTree.c
 *
 * Project 1 - Human Coding
 ***********************************************************************/

#include "BinaryTree.h"
#include <stdlib.h>

/***********************************************************************/

LinkedRoot* newLinkedRoot(BinaryNode* rootNode) {
    LinkedRoot* myNewLink = (LinkedRoot*)malloc(sizeof(LinkedRoot));
    myNewLink->data = rootNode;
    myNewLink->next = NULL;
    return myNewLink;
}

/***********************************************************************/

LinkedRoot* addRoot(LinkedRoot* head, LinkedRoot* newRoot) {
    if(head == NULL || head->data == NULL) {
        return newRoot;
    }
    else if(head->data->frequency < newRoot->data->frequency) {
        head->next = addRoot(head->next, newRoot);
        return head;
    }
    else {
        newRoot->next = head;
        return newRoot;
    }
}

/***********************************************************************/

LinkedRoot* removeLeastRoot(LinkedRoot* head) {
    if(head != NULL) {
        LinkedRoot* returnPointer = head->next;
        free(head);
        return returnPointer;
    }
    else
        return head;
}

/***********************************************************************/

void freeNodes(BinaryNode* head) {
    if(head == NULL)
        return;
    else if(head->left != NULL)
        freeNodes(head->left);
    else if(head->right != NULL)
        freeNodes(head->right);
    
    free(head);
}

/***********************************************************************/

void freeList(LinkedRoot* myList) {
    freeNodes(myList->data);
    free(myList);
}

/***********************************************************************/

BinaryNode* newBinaryNode(int value, int freq) {
    BinaryNode* newNode = (BinaryNode*)malloc(sizeof(BinaryNode));
    newNode->value = value;
    newNode->frequency = freq;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

/***********************************************************************/