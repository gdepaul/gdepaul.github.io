/***********************************************************************
 * Gregory DePaul
 * BinaryTree.h
 *
 * Project 1 - Human Coding
 ***********************************************************************/

#ifndef BinaryTree_h
#define BinaryTree_h

/***********************************************************************/

typedef struct BinaryNodeStruct {
    int value;
    int frequency;
    struct BinaryNodeStruct* left;
    struct BinaryNodeStruct* right;
} BinaryNode;

typedef struct LinkedRootStruct {
    BinaryNode* data;
    struct LinkedRootStruct* next;
}LinkedRoot;

/** Function Prototypes ************************************************/

LinkedRoot* addRoot(LinkedRoot* head, LinkedRoot* newRoot);
LinkedRoot* newLinkedRoot(BinaryNode* rootNode);
LinkedRoot* removeLeastRoot(LinkedRoot* head);
void freeList(LinkedRoot* myList);
BinaryNode* newBinaryNode(int value, int freq);

/***********************************************************************/

#endif /* BinaryTree_h */
